let show_page = async (req, res) => {
    res.send("<h1>Index</h1>")
}

module.exports = {
    show_page
}